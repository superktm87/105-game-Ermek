package kz.bilimai.game105;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.content.Context;
import java.util.ArrayList;
import java.util.List;

public final class GameView extends View {
    final GameEngine engine = new GameEngine();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<RectF> handRects = new ArrayList<>();
    private final RectF deckRect = new RectF(), menuRect = new RectF(), nextRect = new RectF();
    private final Handler handler = new Handler();
    private boolean botScheduled;
    private float density;

    public GameView(Context context) { super(context); density = getResources().getDisplayMetrics().density; engine.newMatch(); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
    private float dp(float n) { return n * density; }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c); float w = getWidth(), h = getHeight();
        paint.setStyle(Paint.Style.FILL); paint.setColor(Color.rgb(18, 78, 57)); c.drawRect(0,0,w,h,paint);
        paint.setColor(Color.rgb(13,57,42)); c.drawRoundRect(new RectF(dp(10),dp(14),w-dp(10),h-dp(14)),dp(24),dp(24),paint);
        drawHeader(c,w);
        drawOpponents(c,w);
        drawTable(c,w,h);
        drawMessage(c,w,h);
        drawHand(c,w,h);
        if (engine.roundOver) drawRoundOverlay(c,w,h);
        scheduleBotIfNeeded();
    }

    private void drawHeader(Canvas c,float w) {
        text(c,"105",dp(25),dp(38),dp(27),Color.WHITE,true);
        text(c,"КОН " + engine.round,dp(90),dp(37),dp(13),0xFF9CCDBA,true);
        menuRect.set(w-dp(58),dp(18),w-dp(20),dp(54));
        paint.setColor(0x33FFFFFF); c.drawRoundRect(menuRect,dp(12),dp(12),paint);
        text(c,"⋮",menuRect.centerX(),dp(46),dp(29),Color.WHITE,true);
    }

    private void drawOpponents(Canvas c,float w) {
        float y=dp(88); float slot=w/3f;
        for(int p=1;p<4;p++) {
            float x=slot*(p-.5f); boolean turn=engine.current==p&&!engine.roundOver;
            paint.setColor(turn?0xFFFFD166:0xFF2D8062); c.drawCircle(x,y-dp(13),dp(20),paint);
            text(c,engine.players[p].name.substring(0,1),x,y-dp(6),dp(17),turn?0xFF173F31:Color.WHITE,true);
            text(c,engine.players[p].name,x,y+dp(21),dp(12),Color.WHITE,true);
            text(c,engine.players[p].hand.size()+" карт · "+engine.players[p].score+" очк.",x,y+dp(39),dp(10),0xFF9CCDBA,true);
        }
    }

    private void drawTable(Canvas c,float w,float h) {
        float cardW=dp(79),cardH=dp(112),y=h*.34f;
        deckRect.set(w/2-cardW-dp(12),y-cardH/2,w/2-dp(12),y+cardH/2);
        drawBack(c,deckRect); text(c,"ОСТАЛОСЬ "+engine.drawPile.size(),deckRect.centerX(),deckRect.bottom+dp(19),dp(10),0xFF9CCDBA,true);
        RectF topRect=new RectF(w/2+dp(12),y-cardH/2,w/2+dp(12)+cardW,y+cardH/2);
        drawCard(c,engine.top(),topRect,false);
        if(engine.orderedSuit!=null) {
            String s=engine.orderedSuit==GameEngine.Suit.CLUBS?"♣":engine.orderedSuit==GameEngine.Suit.DIAMONDS?"♦":engine.orderedSuit==GameEngine.Suit.HEARTS?"♥":"♠";
            text(c,"ЗАКАЗАНО  "+s,w/2,y+cardH/2+dp(24),dp(12),0xFFFFD166,true);
        }
    }

    private void drawMessage(Canvas c,float w,float h) {
        float y=h-dp(206); paint.setColor(0x2220C997); c.drawRoundRect(new RectF(dp(22),y-dp(28),w-dp(22),y+dp(18)),dp(13),dp(13),paint);
        String msg=engine.message; if(msg.length()>48) msg=msg.substring(0,46)+"…";
        text(c,msg,w/2,y,dp(12),Color.WHITE,true);
    }

    private void drawHand(Canvas c,float w,float h) {
        handRects.clear(); List<GameEngine.Card> cards=engine.players[0].hand;
        float cw=dp(64),ch=dp(91),available=w-dp(28),step=cards.size()<=1?0:Math.min(cw+dp(5),(available-cw)/(cards.size()-1));
        float total=cw+step*Math.max(0,cards.size()-1),start=(w-total)/2,y=h-dp(119);
        for(int i=0;i<cards.size();i++){ RectF r=new RectF(start+i*step,y,start+i*step+cw,y+ch); handRects.add(r); drawCard(c,cards.get(i),r,!engine.canPlay(cards.get(i))||engine.current!=0); }
        text(c,"ВАШИ КАРТЫ · "+engine.players[0].score+" ОЧКОВ",dp(22),h-dp(132),dp(11),engine.current==0?0xFFFFD166:0xFF9CCDBA,false);
    }

    private void drawCard(Canvas c,GameEngine.Card card,RectF r,boolean dim) {
        paint.setShadowLayer(dp(5),0,dp(3),0x55000000); paint.setColor(dim?0xFFCAD2CE:0xFFF8F4E8); c.drawRoundRect(r,dp(9),dp(9),paint); paint.clearShadowLayer();
        int color=(card.suit==GameEngine.Suit.HEARTS||card.suit==GameEngine.Suit.DIAMONDS)?0xFFCD3F4F:0xFF183B32; if(dim) color=0xFF77827E;
        text(c,card.rankText(),r.left+dp(9),r.top+dp(22),dp(17),color,false); text(c,card.suitText(),r.left+dp(10),r.top+dp(43),dp(18),color,false);
        text(c,card.suitText(),r.centerX(),r.centerY()+dp(17),dp(39),color,true);
    }
    private void drawBack(Canvas c,RectF r) { paint.setColor(0xFFFFD166); c.drawRoundRect(r,dp(9),dp(9),paint); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(3)); paint.setColor(0xFF234F3E); c.drawRoundRect(new RectF(r.left+dp(7),r.top+dp(7),r.right-dp(7),r.bottom-dp(7)),dp(6),dp(6),paint); paint.setStyle(Paint.Style.FILL); text(c,"105",r.centerX(),r.centerY()+dp(8),dp(26),0xFF234F3E,true); }

    private void drawRoundOverlay(Canvas c,float w,float h) {
        paint.setColor(0xDD102820); c.drawRoundRect(new RectF(dp(25),h*.28f,w-dp(25),h*.71f),dp(22),dp(22),paint);
        text(c,engine.gameOver?"ИГРА ОКОНЧЕНА":"КОН ОКОНЧЕН",w/2,h*.34f,dp(14),0xFFFFD166,true);
        String title=engine.winner==0?"Вы победили!":engine.players[engine.winner].name+" победил(а)";
        text(c,title,w/2,h*.40f,dp(25),Color.WHITE,true);
        float y=h*.47f; for(GameEngine.Player p:engine.players){ text(c,p.name,w*.30f,y,dp(14),0xFFCDE5DB,false); text(c,p.score+" / 105",w*.70f,y,dp(14),p.score>105?0xFFFF6B6B:Color.WHITE,true); y+=dp(28); }
        nextRect.set(dp(55),h*.63f,w-dp(55),h*.69f); paint.setColor(0xFFFFD166); c.drawRoundRect(nextRect,dp(16),dp(16),paint); text(c,engine.gameOver?"НОВАЯ ИГРА":"СЛЕДУЮЩИЙ КОН",w/2,nextRect.centerY()+dp(5),dp(14),0xFF183B32,true);
    }

    private void text(Canvas c,String s,float x,float y,float size,int color,boolean center){ paint.setColor(color);paint.setTextSize(size);paint.setTypeface(android.graphics.Typeface.create("sans",android.graphics.Typeface.BOLD));paint.setTextAlign(center?Paint.Align.CENTER:Paint.Align.LEFT);c.drawText(s,x,y,paint); }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if(e.getAction()!=MotionEvent.ACTION_UP)return true; float x=e.getX(),y=e.getY();
        if(menuRect.contains(x,y)){((MainActivity)getContext()).showMenu();return true;}
        if(engine.roundOver&&nextRect.contains(x,y)){if(engine.gameOver)engine.newMatch();else engine.startRound();afterAction();return true;}
        if(engine.current!=0||engine.roundOver)return true;
        for(int i=handRects.size()-1;i>=0;i--)if(handRects.get(i).contains(x,y)){GameEngine.Card card=engine.players[0].hand.get(i);if(card.rank==GameEngine.Rank.QUEEN&&engine.canPlay(card))((MainActivity)getContext()).chooseSuit(i);else playHuman(i,null);return true;}
        if(deckRect.contains(x,y)){engine.humanDraw();afterAction();return true;} return true;
    }
    void playHuman(int index,GameEngine.Suit suit){engine.humanPlay(index,suit);afterAction();}
    void afterAction(){invalidate();scheduleBotIfNeeded();}
    private void scheduleBotIfNeeded(){if(!engine.roundOver&&engine.current!=0&&!botScheduled){botScheduled=true;handler.postDelayed(()->{botScheduled=false;engine.botTurn();invalidate();scheduleBotIfNeeded();},650);}}
}
