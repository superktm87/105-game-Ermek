package kz.bilimai.game105;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

public final class OnlineGameView extends LinearLayout implements OnlineClient.Listener {
    private final MainActivity activity;
    private final OnlineClient client;
    private final TextView title,status,players,table,message;
    private final LinearLayout hand,actions;
    private JSONObject state;
    private String myId="";
    private boolean host;

    public OnlineGameView(MainActivity a,String url,JSONObject hello) {
        super(a);activity=a;setOrientation(VERTICAL);setGravity(Gravity.CENTER_HORIZONTAL);setPadding(dp(18),dp(28),dp(18),dp(16));setBackgroundColor(0xFF103D2E);
        title=text("105 · ПОДКЛЮЧЕНИЕ",24,Color.WHITE,true);addView(title,match(LinearLayout.LayoutParams.WRAP_CONTENT));
        status=text("Подключаемся…",12,0xFF9CCDBA,false);addView(status,match(LinearLayout.LayoutParams.WRAP_CONTENT));
        players=text("",14,Color.WHITE,false);players.setPadding(0,dp(18),0,dp(18));addView(players,match(LinearLayout.LayoutParams.WRAP_CONTENT));
        table=text("",42,Color.WHITE,true);table.setGravity(Gravity.CENTER);table.setBackgroundColor(0xFF185C45);addView(table,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(145)));
        message=text("Ожидание сервера",13,0xFFFFD166,true);message.setPadding(0,dp(14),0,dp(14));addView(message,match(LinearLayout.LayoutParams.WRAP_CONTENT));
        TextView your=text("ВАШИ КАРТЫ",12,0xFF9CCDBA,true);addView(your,match(LinearLayout.LayoutParams.WRAP_CONTENT));
        hand=new LinearLayout(a);hand.setGravity(Gravity.CENTER);HorizontalScrollView scroll=new HorizontalScrollView(a);scroll.setHorizontalScrollBarEnabled(false);scroll.addView(hand);addView(scroll,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(100)));
        actions=new LinearLayout(a);actions.setGravity(Gravity.CENTER);addView(actions,match(LinearLayout.LayoutParams.WRAP_CONTENT));
        client=new OnlineClient(this);client.connect(url,hello);
    }
    private LinearLayout.LayoutParams match(int h){return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,h);}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color,boolean bold){TextView v=new TextView(activity);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setGravity(Gravity.CENTER);if(bold)v.setTypeface(Typeface.DEFAULT_BOLD);return v;}
    private Button button(String s){Button b=new Button(activity);b.setText(s);b.setTextColor(0xFF153F31);b.setBackgroundColor(0xFFFFD166);b.setAllCaps(false);return b;}
    @Override public void onStatus(String s){status.setText(s);}
    @Override public void onMessage(JSONObject o){
        try{
            String type=o.getString("type");
            if(type.equals("error")){message.setText(o.getString("message"));return;}
            if(type.equals("joined")){
                myId=o.getString("playerId");String room=o.getString("code");title.setText("105 · КОМНАТА "+room);
                activity.getSharedPreferences("online",android.content.Context.MODE_PRIVATE).edit().putString("room",room).putString("token",o.getString("token")).apply();return;
            }
            if(type.equals("state")){state=o;render();}
        }catch(Exception e){message.setText("Ошибка данных: "+e.getMessage());}
    }
    private void render() throws Exception{
        title.setText("105 · КОМНАТА "+state.getString("code"));message.setText(state.optString("message"));JSONArray ps=state.getJSONArray("players");StringBuilder list=new StringBuilder();host=false;
        for(int i=0;i<ps.length();i++){JSONObject p=ps.getJSONObject(i);if(p.getString("id").equals(myId)&&p.getString("id").equals(state.getString("host")))host=true;list.append(p.optBoolean("isYou")?"● ":"○ ").append(p.getString("name")).append("  ·  ").append(p.getInt("count")).append(" карт  ·  ").append(p.getInt("score")).append(" очк.").append(p.getBoolean("connected")?"":"  (нет связи)").append('\n');}
        players.setText(list.toString().trim());boolean started=state.getBoolean("started");
        if(!started){table.setText("Ожидаем игроков\n"+ps.length()+" / 4");hand.removeAllViews();renderActions(false);return;}
        JSONObject top=state.getJSONObject("top");String ordered=state.isNull("ordered")?"":state.optString("ordered","");table.setText(card(top)+"\nКолода: "+state.getInt("deckCount")+(ordered.isEmpty()?"":"  ·  Заказано "+suit(ordered)));
        hand.removeAllViews();JSONArray cards=state.getJSONArray("hand");for(int i=0;i<cards.length();i++){JSONObject c=cards.getJSONObject(i);Button b=button(card(c));b.setTextSize(22);final int index=i;b.setOnClickListener(v->play(index,c.optString("r").equals("Q")));hand.addView(b,new LinearLayout.LayoutParams(dp(70),dp(88)));}
        renderActions(true);
    }
    private void renderActions(boolean started){actions.removeAllViews();try{
        if(!started&&host){Button start=button("Начать игру");start.setEnabled(state.getJSONArray("players").length()==4);start.setOnClickListener(v->send("start"));actions.addView(start);return;}
        if(!started)return;boolean over=state.getBoolean("over");if(over&&host){Button next=button(state.getBoolean("gameOver")?"Новая игра":"Следующий кон");next.setOnClickListener(v->send("next"));actions.addView(next);return;}
        int me=-1;JSONArray ps=state.getJSONArray("players");for(int i=0;i<ps.length();i++)if(ps.getJSONObject(i).optBoolean("isYou"))me=i;
        if(!over&&state.getInt("current")==me){Button draw=button("Взять карты");draw.setOnClickListener(v->send("draw"));actions.addView(draw);}else if(!over){TextView wait=text("Ожидайте ход другого игрока",13,0xFF9CCDBA,false);actions.addView(wait);}
    }catch(Exception ignored){}}
    private void play(int index,boolean queen){if(queen){String[] names={"♣ Трефы","♦ Бубны","♥ Червы","♠ Пики"};new AlertDialog.Builder(activity).setTitle("Заказать масть").setItems(names,(d,w)->sendPlay(index,new String[]{"C","D","H","S"}[w])).show();}else sendPlay(index,null);}
    private void sendPlay(int i,String suit){try{JSONObject o=new JSONObject().put("type","play").put("index",i);if(suit!=null)o.put("suit",suit);client.send(o);}catch(Exception ignored){}}
    private void send(String type){try{client.send(new JSONObject().put("type",type));}catch(Exception ignored){}}
    private String card(JSONObject c){return c.optString("r")+suit(c.optString("s"));}
    private String suit(String s){switch(s){case"C":return"♣";case"D":return"♦";case"H":return"♥";default:return"♠";}}
    public void close(){client.close();}
}
