package kz.bilimai.game105;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;

public final class OnlineLobby {
    private OnlineLobby() {}
    public static void show(MainActivity a) {
        String[] choices={"Создать комнату","Войти по коду"};
        new AlertDialog.Builder(a).setTitle("Игра через интернет").setItems(choices,(d,w)->form(a,w==0)).setNegativeButton("Отмена",null).show();
    }
    private static void form(MainActivity a, boolean create) {
        SharedPreferences p=a.getSharedPreferences("online",Context.MODE_PRIVATE);
        LinearLayout box=new LinearLayout(a);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(48,12,48,0);
        EditText server=new EditText(a);server.setHint("wss://ваш-сервер.example");server.setText(p.getString("server","ws://10.0.2.2:8080"));box.addView(server);
        EditText name=new EditText(a);name.setHint("Ваше имя");name.setText(p.getString("name","Игрок"));box.addView(name);
        EditText code=null;if(!create){code=new EditText(a);code.setHint("Код комнаты");code.setInputType(InputType.TYPE_CLASS_NUMBER);box.addView(code);} final EditText roomCode=code;
        new AlertDialog.Builder(a).setTitle(create?"Новая комната":"Вход в комнату").setView(box).setPositiveButton(create?"Создать":"Войти",(d,w)->{
            String u=server.getText().toString().trim(),n=name.getText().toString().trim();p.edit().putString("server",u).putString("name",n).apply();
            try {
                JSONObject hello=new JSONObject().put("type",create?"create":"join").put("name",n);
                if(!create){
                    String entered=roomCode.getText().toString().trim();hello.put("code",entered);
                    if(entered.equals(p.getString("room","")))hello.put("token",p.getString("token",""));
                }
                a.openOnline(u,hello);
            } catch(Exception ignored){}
        }).setNegativeButton("Отмена",null).show();
    }
}
