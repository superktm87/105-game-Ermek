package kz.bilimai.game105;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import org.json.JSONObject;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;

public final class MainActivity extends Activity {
    private GameView gameView;
    private OnlineGameView onlineView;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            getWindow().getInsetsController().setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            getWindow().getInsetsController().hide(WindowInsets.Type.statusBars());
        }
        gameView = new GameView(this);
        setContentView(gameView);
        new Handler().postDelayed(() -> new AlertDialog.Builder(this).setTitle("Игра 105")
                .setItems(new String[]{"Играть на этом телефоне","Играть через интернет"}, (d,w) -> { if(w==1) OnlineLobby.show(this); })
                .show(), 250);
    }
    public void chooseSuit(final int cardIndex) {
        String[] names = {"♣ Трефы", "♦ Бубны", "♥ Червы", "♠ Пики"};
        new AlertDialog.Builder(this).setTitle("Заказать масть").setItems(names, (d, which) -> {
            gameView.playHuman(cardIndex, GameEngine.Suit.values()[which]);
        }).setNegativeButton("Отмена", null).show();
    }
    public void showMenu() {
        String[] items = {"Новая игра", "Игра через интернет", "Правила", "Режим добора: " + (gameView.engine.drawOneMode ? "одна карта" : "до подходящей")};
        new AlertDialog.Builder(this).setTitle("Игра 105").setItems(items, (d, which) -> {
            if (which == 0) { gameView.engine.newMatch(); gameView.afterAction(); }
            else if (which == 1) OnlineLobby.show(this);
            else if (which == 2) showRules();
            else { gameView.engine.drawOneMode = !gameView.engine.drawOneMode; gameView.invalidate(); }
        }).show();
    }
    public void openOnline(String url, JSONObject hello) {
        onlineView=new OnlineGameView(this,url,hello);setContentView(onlineView);
    }
    @Override public void onBackPressed() {
        if(onlineView!=null){onlineView.close();onlineView=null;gameView=new GameView(this);setContentView(gameView);}else super.onBackPressed();
    }
    private void showRules() {
        new AlertDialog.Builder(this).setTitle("Краткие правила").setMessage(
            "Кройте карту той же мастью или достоинством. Дама подходит всегда и заказывает масть.\n\n" +
            "6 — берите до 6 или дамы.\n7 — следующий берёт 2 и пропускает ход (пиковая — 3).\nТуз — следующий пропускает ход.\n\n" +
            "9 даёт 0 очков; валет — 2, дама — 3, король — 4, туз — 11.\n\n" +
            "Закрытие кона дамой списывает 20 очков, пиковой дамой — 40. Единственная оставшаяся у проигравшего дама приносит 20, пиковая — 40 очков. Ровно 105 очков обнуляются; результат больше 105 означает поражение.")
            .setPositiveButton("Понятно", null).show();
    }
}
