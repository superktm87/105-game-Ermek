package kz.bilimai.game105;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import java.util.concurrent.TimeUnit;

public final class OnlineClient extends WebSocketListener {
    public interface Listener { void onMessage(JSONObject data); void onStatus(String text); }
    private final OkHttpClient http = new OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Listener listener;
    private WebSocket socket;
    public OnlineClient(Listener listener) { this.listener = listener; }
    public void connect(String url, JSONObject hello) {
        Request request = new Request.Builder().url(url).build();
        socket = http.newWebSocket(request, new WebSocketListener() {
            @Override public void onOpen(WebSocket ws, Response response) { main.post(() -> listener.onStatus("Соединено")); ws.send(hello.toString()); }
            @Override public void onMessage(WebSocket ws, String text) { try { JSONObject o=new JSONObject(text); main.post(()->listener.onMessage(o)); } catch(Exception ignored) {} }
            @Override public void onFailure(WebSocket ws, Throwable t, Response r) { main.post(() -> listener.onStatus("Ошибка сети: "+t.getMessage())); }
            @Override public void onClosed(WebSocket ws, int code, String reason) { main.post(() -> listener.onStatus("Соединение закрыто")); }
        });
    }
    public void send(JSONObject value) { if(socket!=null) socket.send(value.toString()); }
    public void close() { if(socket!=null) socket.close(1000,"Выход"); http.dispatcher().executorService().shutdown(); }
}
