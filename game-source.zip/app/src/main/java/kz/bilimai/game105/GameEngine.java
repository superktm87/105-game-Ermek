package kz.bilimai.game105;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public final class GameEngine {
    public enum Suit { CLUBS, DIAMONDS, HEARTS, SPADES }
    public enum Rank { SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING, ACE }

    public static final class Card {
        public final Suit suit;
        public final Rank rank;
        Card(Suit suit, Rank rank) { this.suit = suit; this.rank = rank; }
        public String rankText() {
            switch (rank) { case SIX:return "6"; case SEVEN:return "7"; case EIGHT:return "8";
                case NINE:return "9"; case TEN:return "10"; case JACK:return "В";
                case QUEEN:return "Д"; case KING:return "К"; default:return "Т"; }
        }
        public String suitText() {
            switch (suit) { case CLUBS:return "♣"; case DIAMONDS:return "♦";
                case HEARTS:return "♥"; default:return "♠"; }
        }
        public int points() {
            switch (rank) { case SIX:return 6; case SEVEN:return 7; case EIGHT:return 8;
                case NINE:return 0; case TEN:return 10; case JACK:return 2;
                case QUEEN:return 3; case KING:return 4; default:return 11; }
        }
    }

    public static final class Player {
        public final String name;
        public final List<Card> hand = new ArrayList<>();
        public int score;
        Player(String name) { this.name = name; }
    }

    public final Player[] players = { new Player("Вы"), new Player("Лена"), new Player("Макс"), new Player("Алия") };
    public final List<Card> drawPile = new ArrayList<>();
    public final List<Card> discard = new ArrayList<>();
    public final Random random;
    public int current;
    public int dealer = 3;
    public Suit orderedSuit;
    public boolean roundOver;
    public boolean gameOver;
    public String message = "";
    public int round = 0;
    public int winner = -1;
    public boolean drawOneMode = false;

    public GameEngine() { this(new Random()); }
    public GameEngine(Random random) { this.random = random; }

    public void newMatch() {
        for (Player p : players) p.score = 0;
        dealer = 3; round = 0; gameOver = false; startRound();
    }

    public void startRound() {
        round++; dealer = (dealer + 1) % players.length; winner = -1;
        roundOver = false; orderedSuit = null; drawPile.clear(); discard.clear();
        for (Player p : players) p.hand.clear();
        for (Suit s : Suit.values()) for (Rank r : Rank.values()) drawPile.add(new Card(s, r));
        Collections.shuffle(drawPile, random);
        for (int n = 0; n < 5; n++) for (int p = 0; p < players.length; p++) {
            if (p != dealer || n < 4) players[p].hand.add(drawPile.remove(drawPile.size() - 1));
        }
        Card first = drawPile.remove(drawPile.size() - 1);
        discard.add(first);
        current = (dealer + 1) % players.length;
        message = "Кон " + round + ". Ходит " + players[current].name;
    }

    public Card top() { return discard.get(discard.size() - 1); }

    public boolean canPlay(Card card) {
        Card top = top();
        if (top.rank == Rank.SIX) return card.rank == Rank.SIX || card.rank == Rank.QUEEN;
        if (card.rank == Rank.QUEEN) return true;
        if (orderedSuit != null) return card.suit == orderedSuit;
        return card.suit == top.suit || card.rank == top.rank;
    }

    public boolean humanPlay(int index, Suit queenSuit) {
        if (roundOver || current != 0 || index < 0 || index >= players[0].hand.size()) return false;
        Card c = players[0].hand.get(index);
        if (!canPlay(c)) { message = "Нужна та же масть или достоинство"; return false; }
        if (c.rank == Rank.QUEEN && queenSuit == null) return false;
        play(0, index, queenSuit); return true;
    }

    public void humanDraw() {
        if (roundOver || current != 0) return;
        Card before = top();
        if (before.rank == Rank.SIX) {
            int count = 0;
            while (!hasPlayable(0)) { drawCard(0); count++; }
            message = "Вы взяли карт: " + count + ". Закройте шестёрку";
            return;
        }
        if (hasPlayable(0)) { message = "У вас есть подходящая карта"; return; }
        if (drawOneMode) {
            Card c = drawCard(0);
            if (c != null && canPlay(c)) message = "Подходящую карту можно сыграть";
            else { message = "Подходящей карты нет — ход пропущен"; advance(1); }
        } else {
            int count = 0;
            while (!hasPlayable(0)) { drawCard(0); count++; }
            message = "Вы взяли карт: " + count;
        }
    }

    public void botTurn() {
        if (roundOver || current == 0) return;
        int p = current;
        if (!hasPlayable(p)) {
            if (top().rank == Rank.SIX || !drawOneMode) {
                while (!hasPlayable(p)) drawCard(p);
            } else {
                Card drawn = drawCard(p);
                if (drawn == null || !canPlay(drawn)) { message = players[p].name + " пропускает ход"; advance(1); return; }
            }
        }
        int chosen = chooseBotCard(p);
        Card c = players[p].hand.get(chosen);
        Suit suit = c.rank == Rank.QUEEN ? bestSuit(p, chosen) : null;
        play(p, chosen, suit);
    }

    private int chooseBotCard(int p) {
        int best = -1, bestValue = -1;
        for (int i = 0; i < players[p].hand.size(); i++) {
            Card c = players[p].hand.get(i);
            if (!canPlay(c)) continue;
            int value = c.points() + (c.rank == Rank.SEVEN ? 8 : 0) + (c.rank == Rank.ACE ? 5 : 0);
            if (value > bestValue) { best = i; bestValue = value; }
        }
        return best;
    }

    private Suit bestSuit(int p, int excluded) {
        int[] counts = new int[4];
        for (int i = 0; i < players[p].hand.size(); i++) if (i != excluded) counts[players[p].hand.get(i).suit.ordinal()]++;
        int best = 0;
        for (int i = 1; i < counts.length; i++) if (counts[i] > counts[best]) best = i;
        return Suit.values()[best];
    }

    private void play(int p, int index, Suit queenSuit) {
        Card c = players[p].hand.remove(index);
        discard.add(c);
        orderedSuit = c.rank == Rank.QUEEN ? queenSuit : null;
        message = players[p].name + " сыграл(а) " + c.rankText() + c.suitText();
        if (c.rank == Rank.QUEEN) message += " и заказал(а) " + suitName(queenSuit);
        if (players[p].hand.isEmpty()) { finishRound(p); return; }
        if (c.rank == Rank.SEVEN) {
            int victim = next(p, 1); int penalty = c.suit == Suit.SPADES ? 3 : 2;
            for (int i = 0; i < penalty; i++) drawCard(victim);
            message += ". " + players[victim].name + " берёт " + penalty + " и пропускает ход";
            current = next(p, 2);
        } else if (c.rank == Rank.ACE) {
            int victim = next(p, 1);
            message += ". " + players[victim].name + " пропускает ход";
            current = next(p, 2);
        } else current = next(p, 1);
    }

    private void finishRound(int p) {
        winner = p; roundOver = true;
        StringBuilder added = new StringBuilder();
        Card closingCard = top();
        int closingBonus = closingCard.rank == Rank.QUEEN
                ? (closingCard.suit == Suit.SPADES ? 40 : 20) : 0;
        if (closingBonus > 0) players[p].score -= closingBonus;
        for (int i = 0; i < players.length; i++) if (i != p) {
            int points;
            if (players[i].hand.size() == 1 && players[i].hand.get(0).rank == Rank.QUEEN) {
                points = players[i].hand.get(0).suit == Suit.SPADES ? 40 : 20;
            } else {
                points = 0; for (Card c : players[i].hand) points += c.points();
            }
            players[i].score += points;
            if (players[i].score == 105) players[i].score = 0;
            if (added.length() > 0) added.append(", ");
            added.append(players[i].name).append(" +").append(points);
            if (players[i].score > 105) gameOver = true;
        }
        message = players[p].name + " выиграл(а) кон"
                + (closingBonus > 0 ? " и списал(а) " + closingBonus + " очков" : "")
                + ". " + added;
    }

    private boolean hasPlayable(int p) { for (Card c : players[p].hand) if (canPlay(c)) return true; return false; }
    private Card drawCard(int p) {
        if (drawPile.isEmpty()) recycle();
        if (drawPile.isEmpty()) return null;
        Card c = drawPile.remove(drawPile.size() - 1); players[p].hand.add(c); return c;
    }
    private void recycle() {
        if (discard.size() <= 1) return;
        Card top = discard.remove(discard.size() - 1);
        drawPile.addAll(discard); discard.clear(); discard.add(top); Collections.shuffle(drawPile, random);
    }
    private int next(int p, int n) { return (p + n) % players.length; }
    private void advance(int n) { current = next(current, n); }
    public static String suitName(Suit s) {
        if (s == null) return "";
        switch (s) { case CLUBS:return "трефы"; case DIAMONDS:return "бубны"; case HEARTS:return "червы"; default:return "пики"; }
    }
}
