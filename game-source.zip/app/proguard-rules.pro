# No shrinking rules are needed for this small offline app.
