import http from 'node:http';
import crypto from 'node:crypto';
import { WebSocketServer } from 'ws';

const PORT = Number(process.env.PORT || 8080);
const rooms = new Map();
const suits = ['C','D','H','S'];
const ranks = ['6','7','8','9','10','J','Q','K','A'];
const points = {6:6,7:7,8:8,9:0,10:10,J:2,Q:3,K:4,A:11};
const id = (n=12) => crypto.randomBytes(n).toString('hex');
const code = () => { let c; do c=String(crypto.randomInt(100000,1000000)); while(rooms.has(c)); return c; };
const send = (ws, value) => ws?.readyState === 1 && ws.send(JSON.stringify(value));

function deck() { return suits.flatMap(s=>ranks.map(r=>({s,r}))); }
function shuffle(a) { for(let i=a.length-1;i;i--){const j=crypto.randomInt(i+1);[a[i],a[j]]=[a[j],a[i]];} return a; }
function next(room,p,n=1){return (p+n)%room.players.length;}
function recycle(room){if(room.discard.length<=1)return;const top=room.discard.pop();room.deck=shuffle(room.discard);room.discard=[top];}
function draw(room,p){if(!room.deck.length)recycle(room);const c=room.deck.pop();if(c)room.players[p].hand.push(c);return c;}
function canPlay(room,c){const top=room.discard.at(-1);if(top.r==='6')return c.r==='6'||c.r==='Q';if(c.r==='Q')return true;if(room.ordered)return c.s===room.ordered;return c.s===top.s||c.r===top.r;}
function hasPlay(room,p){return room.players[p].hand.some(c=>canPlay(room,c));}
function startRound(room){
  room.round++; room.dealer=(room.dealer+1)%room.players.length; room.deck=shuffle(deck()); room.discard=[]; room.ordered=null; room.over=false; room.winner=-1;
  room.players.forEach(p=>p.hand=[]);
  for(let n=0;n<5;n++)for(let p=0;p<room.players.length;p++)if(p!==room.dealer||n<4)draw(room,p);
  room.discard.push(room.deck.pop()); room.current=next(room,room.dealer); room.message=`Кон ${room.round}. Ходит ${room.players[room.current].name}`;
}
function finish(room,p){
  room.over=true;room.winner=p;const closing=room.discard.at(-1);const bonus=closing.r==='Q'?(closing.s==='S'?40:20):0;if(bonus)room.players[p].score-=bonus;
  const added=[];room.players.forEach((pl,i)=>{if(i===p)return;let pts=pl.hand.length===1&&pl.hand[0].r==='Q'?(pl.hand[0].s==='S'?40:20):pl.hand.reduce((a,c)=>a+points[c.r],0);pl.score+=pts;if(pl.score===105)pl.score=0;added.push(`${pl.name} +${pts}`);});
  room.gameOver=room.players.some(pl=>pl.score>105);room.message=`${room.players[p].name} выиграл(а) кон${bonus?` и списал(а) ${bonus}`:''}. ${added.join(', ')}`;
}
function play(room,p,index,suit){
  if(room.over||room.current!==p)throw Error('Сейчас не ваш ход');const c=room.players[p].hand[index];if(!c||!canPlay(room,c))throw Error('Этой картой ходить нельзя');if(c.r==='Q'&&!suits.includes(suit))throw Error('Выберите масть');
  room.players[p].hand.splice(index,1);room.discard.push(c);room.ordered=c.r==='Q'?suit:null;room.message=`${room.players[p].name} сыграл(а) ${c.r}${c.s}`;if(!room.players[p].hand.length)return finish(room,p);
  if(c.r==='7'){const victim=next(room,p),n=c.s==='S'?3:2;for(let i=0;i<n;i++)draw(room,victim);room.current=next(room,p,2);room.message+=`. ${room.players[victim].name} берёт ${n} и пропускает ход`;}
  else if(c.r==='A'){const victim=next(room,p);room.current=next(room,p,2);room.message+=`. ${room.players[victim].name} пропускает ход`;}
  else room.current=next(room,p);
}
function take(room,p){
  if(room.over||room.current!==p)throw Error('Сейчас не ваш ход');if(hasPlay(room,p))throw Error('У вас есть подходящая карта');let n=0;
  while(!hasPlay(room,p)){if(!draw(room,p))throw Error('Нет доступных карт');n++;}
  room.message=`${room.players[p].name} взял(а) карт: ${n}`;
}
function state(room,viewer){return {type:'state',code:room.code,host:room.host,started:room.started,round:room.round,current:room.current,dealer:room.dealer,ordered:room.ordered,top:room.discard.at(-1)||null,deckCount:room.deck.length,over:room.over,gameOver:room.gameOver,winner:room.winner,message:room.message,players:room.players.map((p,i)=>({id:p.id,name:p.name,score:p.score,count:p.hand.length,connected:!!p.ws,isYou:i===viewer})),hand:viewer>=0?room.players[viewer].hand:[]};}
function broadcast(room){room.players.forEach((p,i)=>send(p.ws,state(room,i)));}
function findPlayer(room,token){return room.players.findIndex(p=>p.token===token);}

const server=http.createServer((req,res)=>{res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify({name:'105 server',rooms:rooms.size,ok:true}));});
const wss=new WebSocketServer({server});
wss.on('connection',ws=>{
  let joined=null,player=-1;
  ws.on('message',raw=>{try{
    const m=JSON.parse(raw.toString());
    if(m.type==='create'){
      const c=code(),token=id();joined={code:c,host:null,players:[],started:false,round:0,dealer:3,deck:[],discard:[],ordered:null,current:0,over:false,gameOver:false,winner:-1,message:'Ожидание игроков'};const p={id:id(4),token,name:String(m.name||'Игрок').slice(0,16),score:0,hand:[],ws};joined.players.push(p);joined.host=p.id;rooms.set(c,joined);player=0;send(ws,{type:'joined',code:c,token,playerId:p.id});broadcast(joined);
    } else if(m.type==='join'){
      joined=rooms.get(String(m.code));if(!joined)throw Error('Комната не найдена');let idx=m.token?findPlayer(joined,m.token):-1;
      if(idx>=0){player=idx;joined.players[idx].ws=ws;}else{if(joined.started)throw Error('Игра уже началась');if(joined.players.length>=4)throw Error('Комната заполнена');const p={id:id(4),token:id(),name:String(m.name||'Игрок').slice(0,16),score:0,hand:[],ws};joined.players.push(p);player=joined.players.length-1;send(ws,{type:'joined',code:joined.code,token:p.token,playerId:p.id});}broadcast(joined);
    } else {
      if(!joined||player<0)throw Error('Сначала войдите в комнату');
      if(m.type==='start'){if(joined.players[player].id!==joined.host)throw Error('Запускает только хозяин');if(joined.players.length!==4)throw Error('Нужно ровно 4 игрока');joined.started=true;joined.gameOver=false;joined.players.forEach(p=>p.score=0);startRound(joined);}
      else if(m.type==='play')play(joined,player,Number(m.index),m.suit);
      else if(m.type==='draw')take(joined,player);
      else if(m.type==='next'){if(!joined.over)throw Error('Кон ещё идёт');if(joined.players[player].id!==joined.host)throw Error('Продолжает хозяин');if(joined.gameOver){joined.players.forEach(p=>p.score=0);joined.round=0;joined.gameOver=false;}startRound(joined);}
      broadcast(joined);
    }
  }catch(e){send(ws,{type:'error',message:e.message||'Ошибка'});}});
  ws.on('close',()=>{if(joined&&player>=0){joined.players[player].ws=null;broadcast(joined);if(joined.players.every(p=>!p.ws))setTimeout(()=>{if(joined.players.every(p=>!p.ws))rooms.delete(joined.code);},30*60*1000);}});
});
server.listen(PORT,'0.0.0.0',()=>console.log(`105 server listening on :${PORT}`));
